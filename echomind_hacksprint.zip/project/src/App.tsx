import React, { useState, useEffect } from 'react';
import { Brain, Mic, MicOff, LineChart, History } from 'lucide-react';
import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition';
import { auth } from './lib/firebase';
import { saveJournalEntry } from './lib/journal';
import { onAuthStateChanged, signInAnonymously } from 'firebase/auth';

function App() {
  const [text, setText] = useState('');
  const [userId, setUserId] = useState<string | null>(null);
  const [sentiment, setSentiment] = useState<'positive' | 'neutral' | 'negative'>('neutral');
  const {
    transcript,
    listening,
    resetTranscript,
    browserSupportsSpeechRecognition
  } = useSpeechRecognition();

  useEffect(() => {
    // Sign in anonymously when the app loads
    const signInUser = async () => {
      try {
        const userCredential = await signInAnonymously(auth);
        setUserId(userCredential.user.uid);
      } catch (error) {
        console.error('Error signing in:', error);
      }
    };

    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setUserId(user.uid);
      } else {
        signInUser();
      }
    });

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (transcript) {
      setText((prevText) => prevText + ' ' + transcript);
    }
  }, [transcript]);

  const handleStartListening = () => {
    resetTranscript();
    SpeechRecognition.startListening({ continuous: true });
  };

  const handleStopListening = () => {
    SpeechRecognition.stopListening();
  };

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
  };

  const handleSave = async () => {
    if (!userId || !text.trim()) return;

    try {
      await saveJournalEntry({
        text: text.trim(),
        sentiment,
        timestamp: new Date(),
        userId,
        wordCount
      });
      
      setText('');
      setSentiment('neutral');
    } catch (error) {
      console.error('Error saving entry:', error);
    }
  };

  const wordCount = text.trim().split(/\s+/).filter(Boolean).length;

  if (!browserSupportsSpeechRecognition) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 to-indigo-50">
        <div className="bg-white p-8 rounded-lg shadow-lg">
          <p className="text-lg text-gray-800">
            Sorry, your browser doesn't support speech recognition.
            Please try using a modern browser like Chrome.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Brain className="h-8 w-8 text-indigo-600" />
              <h1 className="text-2xl font-bold text-gray-900">EchoMind</h1>
            </div>
            <nav className="flex space-x-4">
              <button className="text-gray-600 hover:text-gray-900 flex items-center space-x-1">
                <History className="h-5 w-5" />
                <span>History</span>
              </button>
              <button className="text-gray-600 hover:text-gray-900 flex items-center space-x-1">
                <LineChart className="h-5 w-5" />
                <span>Insights</span>
              </button>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow-lg p-6">
          {/* Journal Entry Section */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-gray-900">New Journal Entry</h2>
              <div className="flex space-x-2">
                <button
                  onClick={listening ? handleStopListening : handleStartListening}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                    listening
                      ? 'bg-red-600 hover:bg-red-700 text-white'
                      : 'bg-indigo-600 hover:bg-indigo-700 text-white'
                  }`}
                >
                  {listening ? (
                    <>
                      <MicOff className="h-5 w-5" />
                      <span>Stop Recording</span>
                    </>
                  ) : (
                    <>
                      <Mic className="h-5 w-5" />
                      <span>Start Recording</span>
                    </>
                  )}
                </button>
                <button
                  onClick={handleSave}
                  disabled={!text.trim()}
                  className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Save Entry
                </button>
              </div>
            </div>
            <div className="relative">
              <textarea
                value={text}
                onChange={handleTextChange}
                className="w-full h-48 p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                placeholder="Start speaking or type your thoughts here..."
              />
              {listening && (
                <div className="absolute bottom-4 right-4 flex items-center space-x-2">
                  <span className="animate-pulse flex h-3 w-3 rounded-full bg-red-600"></span>
                  <span className="text-sm text-gray-500">Recording...</span>
                </div>
              )}
            </div>
          </div>

          {/* Sentiment Analysis Preview */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h3 className="text-lg font-medium text-gray-900 mb-2">Sentiment Analysis</h3>
            <div className="flex items-center space-x-4">
              <div className="flex-1 bg-white p-4 rounded-lg shadow-sm">
                <p className="text-sm text-gray-500">Current Mood</p>
                <p className="text-lg font-medium text-gray-900">{sentiment}</p>
              </div>
              <div className="flex-1 bg-white p-4 rounded-lg shadow-sm">
                <p className="text-sm text-gray-500">Entry Length</p>
                <p className="text-lg font-medium text-gray-900">{wordCount} words</p>
              </div>
              <div className="flex-1 bg-white p-4 rounded-lg shadow-sm">
                <p className="text-sm text-gray-500">Time</p>
                <p className="text-lg font-medium text-gray-900">{new Date().toLocaleTimeString()}</p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;