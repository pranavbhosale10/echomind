export interface JournalEntry {
  id?: string;
  text: string;
  sentiment: 'positive' | 'neutral' | 'negative';
  timestamp: Date;
  userId: string;
  wordCount: number;
}