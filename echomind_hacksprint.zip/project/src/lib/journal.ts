import { collection, addDoc, query, where, orderBy, getDocs } from 'firebase/firestore';
import { db } from './firebase';
import type { JournalEntry } from '../types/journal';

export const saveJournalEntry = async (entry: Omit<JournalEntry, 'id'>) => {
  try {
    const docRef = await addDoc(collection(db, 'journal_entries'), {
      ...entry,
      timestamp: entry.timestamp.toISOString()
    });
    return docRef.id;
  } catch (error) {
    console.error('Error saving journal entry:', error);
    throw error;
  }
};

export const getJournalEntries = async (userId: string) => {
  try {
    const q = query(
      collection(db, 'journal_entries'),
      where('userId', '==', userId),
      orderBy('timestamp', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      timestamp: new Date(doc.data().timestamp)
    })) as JournalEntry[];
  } catch (error) {
    console.error('Error fetching journal entries:', error);
    throw error;
  }
};